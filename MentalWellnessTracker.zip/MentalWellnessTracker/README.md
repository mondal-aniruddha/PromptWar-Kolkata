# MindMate: Generative AI Exam Wellness Companion

MindMate is a full-stack demo for students preparing for high-stakes exams such as NEET, JEE, CUET, CAT, GATE, UPSC, and board exams.

It combines open-ended journaling, mood logs, stress analysis, pattern detection, and conversational wellness support through a React frontend connected to a Java REST backend.

## Features

- Daily mood, stress, energy, sleep, exam-track, and journal logging
- Local GenAI-style analysis that identifies triggers, emotions, hidden patterns, and coping strategies
- Companion chat for contextual encouragement and adaptive exercises
- Dashboard with average mood, stress, sleep, trend chart, latest reflection, and recommended plan
- Safety-aware crisis language handling that redirects students toward trusted human and emergency support

## Run The Backend

```powershell
cd backend
javac -d out (Get-ChildItem -Recurse src/main/java/*.java)
java -cp out com.mindmate.Main
```

The API runs on `http://localhost:9090`.

## Run The Frontend

```powershell
cd frontend
pnpm install
pnpm dev
```

The app runs on the Vite URL shown in the terminal, usually `http://127.0.0.1:5173`.

## API Endpoints

- `GET /api/health`
- `GET /api/entries`
- `POST /api/entries`
- `GET /api/insights`
- `POST /api/chat`

## Where GenAI Fits

The backend currently uses a deterministic local analysis engine so the project can run without API keys. The service boundary is isolated in `backend/src/main/java/com/mindmate/service/WellnessService.java`, where a hosted LLM call can be added later for richer summarization and conversation.
