import com.mindmate.Main;

public class App {
    public static void main(String[] args) throws Exception {
        Main.main(args);
    }
}
